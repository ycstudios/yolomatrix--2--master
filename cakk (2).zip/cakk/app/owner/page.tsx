"use client";

import { useEffect, useState } from "react";

export default function OwnerPage() {
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [callerId, setCallerId] = useState<string | null>(null);

  useEffect(() => {
    const signalingUrl = process.env.NEXT_PUBLIC_SIGNALING_URL;

    if (!signalingUrl) {
      console.error("NEXT_PUBLIC_SIGNALING_URL is not set");
      return;
    }

    const newWs = new WebSocket(signalingUrl);

    newWs.onopen = () => {
      console.log("Connected to signaling server as owner");
    };

    newWs.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);

        if (data.type === "connected") {
          setUserId(data.id);
        }

        if (data.type === "call") {
          setCallerId(data.payload.callerId);
          alert(`Incoming call from ${data.payload.callerId}`);
        }
      } catch (e) {
        console.error("Failed to parse message", e);
      }
    };

    newWs.onclose = () => {
      console.log("Disconnected from signaling server");
    };

    newWs.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    setWs(newWs);

    return () => {
      newWs.close();
    };
  }, []);

  return (
    <div>
      <h1>Support Agent Dashboard</h1>
      {callerId && <p>Incoming call from: {callerId}</p>}
      {!callerId && <p>Waiting for calls...</p>}
      {userId && <p>Your User ID: {userId}</p>}
    </div>
  );
}