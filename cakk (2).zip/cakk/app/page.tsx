import Hero from "@/components/hero"
import SearchForm from "@/components/search-form"
import LuxuryCollection from "@/components/luxury-collection"
import WhyChooseUs from "@/components/why-choose-us"
import Footer from "@/components/footer"
import FloatingActions from "@/components/floating-actions"
import ClientShowcase from '@/components/ClientShowcase'
import  TravelPackages from '@/components/TravelPackages'
import { CallButton, CallInterface } from "@/components/call"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <SearchForm />
      <TravelPackages/>
      <LuxuryCollection />
       <div className="z-10 max-w-5xl w-full items-center justify-center font-mono text-sm flex flex-col">
        <h1 className="text-4xl font-bold mb-8">Web Calling Demo</h1>

        <div className="mb-8 text-center">
          <p className="mb-4">Click the button below to start a call with the website owner</p>
          <CallButton size="lg" />
        </div>

        <div className="mt-8 text-center text-gray-500">
          <p>When you click the call button, your browser will request access to your camera and microphone.</p>
          <p>The call interface will appear once the connection is established.</p>
        </div>

        {/* Call interface will appear when a call is active */}
        <CallInterface />
      </div>
      <WhyChooseUs />
      <ClientShowcase/>
      <Footer />
      <FloatingActions />
    </main>
  )
}
