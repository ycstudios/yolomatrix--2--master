import { type NextRequest, NextResponse } from "next/server"

// In-memory store for active connections and pending messages
// In production, use Redis or another distributed store
const connections: Record<string, { lastPing: number }> = {}
const pendingMessages: Record<string, any[]> = {}

// Clean up stale connections every 5 minutes
setInterval(
  () => {
    const now = Date.now()
    Object.keys(connections).forEach((id) => {
      if (now - connections[id].lastPing > 5 * 60 * 1000) {
        delete connections[id]
        delete pendingMessages[id]
      }
    })
  },
  5 * 60 * 1000,
)

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { type, from, to, payload } = data

    if (!from) {
      return NextResponse.json({ error: "Missing from ID", success: false }, { status: 400 })
    }

    // Update last ping time
    if (!connections[from]) {
      connections[from] = { lastPing: Date.now() }
    } else {
      connections[from].lastPing = Date.now()
    }

    // Handle different message types
    switch (type) {
      case "ping":
        return NextResponse.json({ success: true })

      case "offer":
      case "answer":
      case "ice-candidate":
      case "call-rejected":
        if (!to) {
          return NextResponse.json({ error: "Missing to ID", success: false }, { status: 400 })
        }

        // Store message for recipient to poll
        if (!connections[to]) {
          connections[to] = { lastPing: Date.now() }
        }

        // Initialize pending messages array if it doesn't exist
        if (!pendingMessages[to]) {
          pendingMessages[to] = []
        }

        // Add message to pending messages
        pendingMessages[to].push({
          type,
          from,
          to,
          payload,
          timestamp: Date.now(),
        })

        return NextResponse.json({
          success: true,
          message: `${type} from ${from} to ${to} received`,
        })

      default:
        return NextResponse.json({ error: "Invalid message type", success: false }, { status: 400 })
    }
  } catch (error) {
    console.error("Error in signaling POST:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        success: false,
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const clientId = searchParams.get("clientId")

    if (!clientId) {
      return NextResponse.json({ error: "Missing clientId", success: false }, { status: 400 })
    }

    // Update last ping time
    if (!connections[clientId]) {
      connections[clientId] = { lastPing: Date.now() }
    } else {
      connections[clientId].lastPing = Date.now()
    }

    // Get pending messages for this client
    const messages = pendingMessages[clientId] || []

    // Clear pending messages after sending them
    pendingMessages[clientId] = []

    return NextResponse.json({
      success: true,
      messages,
    })
  } catch (error) {
    console.error("Error in signaling GET:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        success: false,
        messages: [],
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
