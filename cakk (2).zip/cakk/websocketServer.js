// websocketServer.js

import { WebSocketServer } from 'ws';
import { randomUUID } from 'crypto';

const wss = new WebSocketServer({ port: 3001 });

const sockets = new Map();

wss.on('connection', ws => {
  const id = randomUUID();  // Generates a unique user ID
  sockets.set(id, ws);
  console.log('Client connected:', id);

  ws.on('message', message => {
    console.log('Received message from', id, ':', message.toString());
    try {
      const parsedMessage = JSON.parse(message.toString());
      const { target, type, payload } = parsedMessage;

      if (!target) {
        console.warn('No target specified for message.');
        return;
      }

      if (sockets.has(target)) {
        const targetSocket = sockets.get(target);
        targetSocket.send(JSON.stringify({
          from: id,
          type,
          payload,
        }));
        console.log(`Message sent from ${id} to ${target}`);
      } else {
        console.warn('Target client not found:', target);
      }
    } catch (error) {
      console.error('Failed to parse message or send:', error);
    }
  });

  ws.on('close', () => {
    sockets.delete(id);
    console.log('Client disconnected:', id);
  });

  ws.on('error', error => {
    console.error('WebSocket error:', error);
  });

  // Send a message back to the client when they connect
  ws.send(JSON.stringify({
    type: 'connected',
    id: id,
  }));
});

console.log('WebSocket server started on port 3001');
